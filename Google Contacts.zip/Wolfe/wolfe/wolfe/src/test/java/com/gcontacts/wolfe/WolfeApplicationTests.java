package com.gcontacts.wolfe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WolfeApplicationTests {

	@Test
	void contextLoads() {
	}

}

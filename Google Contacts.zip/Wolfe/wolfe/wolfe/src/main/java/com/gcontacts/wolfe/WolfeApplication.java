package com.gcontacts.wolfe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WolfeApplication {

	public static void main(String[] args) {
		SpringApplication.run(WolfeApplication.class, args);
	}

}

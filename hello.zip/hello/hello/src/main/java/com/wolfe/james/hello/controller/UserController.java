package com.wolfe.james.hello.controller;

public class UserController {
}
